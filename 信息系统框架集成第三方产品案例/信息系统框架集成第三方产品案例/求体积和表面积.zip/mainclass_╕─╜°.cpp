#include<iostream>
using namespace std;
#include"Shape.h"
#include"Cube.h"
#include "Sphere.h"
#include "Cylinder.h"

int Cal_SurfaceAreaVolume01(Shape* sp)
{
	int ret = 0;
	ret = sp->SurfaceArea();
	if (ret != 0)
	{
		cout << "sp->SurfaceArea()err:" << ret << endl;
		return ret;
	}
	ret = sp->Volume();
	if (ret != 0)
	{
		cout << "sp->SurfaceArea()err:" << ret << endl;
		return ret;
	}
	return 0;
}
int main()
{
	Shape* sp = NULL;
	//sp= new Cube(10, 20, 30);
	//sp= new Sphere(10);
	sp = new Cylinder(10, 20);
	int ret = 0;

	ret = Cal_SurfaceAreaVolume01(sp);
	if (ret != 0)
	{
		cout << "Cal_SurfaceAreaVolume err:" << ret << endl;
		goto End;
	}

End:
	delete sp;
	system("pause");
	return ret;
}