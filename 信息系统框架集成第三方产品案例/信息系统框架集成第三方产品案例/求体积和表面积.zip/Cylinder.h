#pragma once
#include"Shape.h"
class Cylinder:public Shape
{
public:
	Cylinder(int r, int l)
	{
		this->r = r;
		this->l = l;
	}
	virtual double SurfaceArea();
	virtual double  Volume();
private:
	int r;
	int l;
};


