#pragma once
#include"Shape.h"
class Cube:public Shape
{
public:
	Cube(int a, int b, int c)
	{
		this->a = a;
		this->b = b;
		this->c = c;
	}
	virtual double SurfaceArea();
	virtual double  Volume();
private:
	int a;
	int b;
	int c;
};

